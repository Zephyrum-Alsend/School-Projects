// Function is defined for each variable between 0 and 3.
double OptFunc(double x, double, double z);