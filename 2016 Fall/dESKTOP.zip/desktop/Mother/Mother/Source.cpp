#include <iostream>
#include "OptFunc.h"

using namespace std;
const double HALT_RANGE = 1;

int main()
{
	struct blah {
		double upper = 5.0;
		double middle = 0.0;
		double lower = 0.0;
	}
		x,
		y,
		z;

	double
		xUp,
		xDown,
		yUp,
		yDown,
		zUp,
		zDown;

	auto f = OptFunc;

	double best;


	// in the future, everything will not be in main <3
	while (true) {
		x.middle = (x.upper + x.lower) / 2;
		y.middle = (y.upper + y.lower) / 2;
		z.middle = (z.upper + z.lower) / 2;


		xDown = f(x.middle / 2, y.middle, z.middle);
		xUp = f(3 * x.middle / 2, y.middle, z.middle);
		cout << "x Down : " << xDown << endl;
		cout << "x Up : " << xUp << endl << endl;
		if (xDown < xUp)
		{
			best = xUp;
			x.lower = x.middle;
		}
		else
		{
			best = xDown;
			x.upper = x.middle;
		}
		x.middle = abs((x.lower - x.upper) / 2);


		yDown = f(x.middle, y.middle / 2, z.middle);
		yUp = f(x.middle, 3 * y.middle / 2, z.middle);
		cout << "y Down : " << yDown << endl;
		cout << "y Up : " << yUp << endl << endl;
		if (yDown < yUp)
		{
			best = yUp;
			y.lower = y.middle;
		}
		else
		{
			best = yDown;
			y.upper = y.middle;
		}
		y.middle = abs((y.lower - y.upper) / 2);
			

		zDown = f(x.middle, y.middle, z.middle / 2);
		zUp = f(x.middle, y.middle, 3 * z.middle / 2);
		cout << "z Down : " << zDown << endl;
		cout << "z Up : " << zUp << endl << endl;
		if (zDown < zUp)
		{
			best = zUp;
			z.lower = z.middle;
		}
		else
		{
			best = zDown;
			z.upper = z.middle;
		}
		z.middle = abs((z.lower - z.upper) / 2);

		if ((HALT_RANGE > x.upper - x.lower)
			&& (HALT_RANGE > y.upper - y.lower)
			&& (HALT_RANGE > z.upper - z.lower))
		{
			break;
		}

		cout << "\n\n\n";
	}

	cout << "\nX: " << x.middle;
	cout << "\nY: " << y.middle;
	cout << "\nZ: " << z.middle;
	cout << "\nFinal Optimized Value:" << best;

	system("pause");

}